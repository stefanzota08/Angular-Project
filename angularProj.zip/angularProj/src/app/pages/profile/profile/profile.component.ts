import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Firestore, deleteDoc, updateDoc, doc } from '@angular/fire/firestore';
import { collection } from 'firebase/firestore';
import { collectionData } from 'rxfire/firestore';
import { filter, map, switchMap } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';
import { Auth, onAuthStateChanged } from '@angular/fire/auth';
import { PdfViewerComponent } from 'ng2-pdf-viewer';
import {
  getBlob,
  getDownloadURL,
  getStorage,
  ref,
  uploadBytes,
} from 'firebase/storage';
import { Observable } from 'rxjs';
import { signInWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  showFileUpload: boolean = false;
  display: boolean = false;
  user: any = null;
  profilePic: any;
  imageURL!: string;
  users$!: Observable<any>;
  infoForm: FormGroup = this.fb.group({
    name: [''],
    phone: [''],
  });
  constructor(
    private readonly firestore: Firestore,
    private readonly authService: AuthService,
    private readonly fb: FormBuilder,
    private readonly auth: Auth,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    // Get a reference to the storage service, which is used to create references in your storage bucket

    // Create a storage reference from our storage service

    this.authService.userData$
      .pipe(
        switchMap((userEmail) => {
          const userCollection = collection(this.firestore, 'users');
          return collectionData(userCollection, { idField: 'id' }).pipe(
            map((users) => {
              return users.filter(
                (user) => user?.email === userEmail?.email
              )[0];
            })
          );
        })
      )
      .subscribe((data) => {
        this.user = data;
        console.log(this.user);
        this.infoForm.setValue({
          name: this.user?.name,
          phone: this.user?.phone.toString(),
        });
      });
  }

  fileChange(e: any) {
    this.profilePic = e.target.files[0];
  }

  fileUpload() {
    this.showFileUpload = false;
    const storage = getStorage();
    const imageRef = ref(storage, this.profilePic.name);
    uploadBytes(imageRef, this.profilePic).then((snapshot) => {
      getDownloadURL(imageRef)
        .then((url) => {
          this.imageURL = url;
          const docRef = doc(this.firestore, 'users', this.user?.id);
          return updateDoc(docRef, {
            profilePicture: this.imageURL,
          });
        })
        .catch((error) => {
          console.log(error);
        });
    });
  }

  infoUpload() {
    this.display = false;
    const docRef = doc(this.firestore, 'users', this.user?.id);
    return updateDoc(docRef, {
      name: this.infoForm.get('name')?.value,
      phone: this.infoForm.get('phone')?.value,
    });
  }

  deleteAccount() {
    const user = this.auth.currentUser;
    this.authService.deleteAccount(user).subscribe(() => {
      deleteDoc(doc(this.firestore, 'users', this.user.id));
      this.router.navigate(['/login']);
      console.log('User Deleted');
    });
  }

  showModal() {
    this.display = true;
  }

  showUploadFile() {
    this.showFileUpload = true;
  }
}
