import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { catchError, switchMap, take } from 'rxjs/operators';
import { addDoc, collection, Firestore } from '@angular/fire/firestore';
import { of } from 'rxjs';
import { FirebaseError } from 'firebase/app';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  emailError: string = '';
  showErrors: boolean = false;
  registerForm!: FormGroup;

  isActive: boolean = true;
  firebaseErrorMessage!: string;

  constructor(
    private readonly fb: FormBuilder,
    private readonly authService: AuthService,
    private readonly firestore: Firestore,
    private readonly router: Router
  ) {
    this.firebaseErrorMessage = '';
  }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.minLength(10)]],
      password: ['', Validators.minLength(6)],
      confirmPassword: ['', Validators.required],
    });
  }

  register() {
    if (this.registerForm.invalid) {
      this.showErrors = true;
      return;
    }
    if (
      this.registerForm.get('password')?.value !==
      this.registerForm.get('confirmPassword')?.value
    ) {
      this.showErrors = true;
      return;
    }
    this.authService
      .signupUser(this.registerForm.value)
      .pipe(
        take(1),
        switchMap(() => {
          let email = this.registerForm.value.email;
          let name = this.registerForm.value.lastName;
          let phone = this.registerForm.value.phone.toString();
          let profilePicture =
            'https://firebasestorage.googleapis.com/v0/b/angular-project-6bf1f.appspot.com/o/default.png?alt=media&token=70d00a15-1030-43ba-a33d-306502967360';
          const userRef = collection(this.firestore, 'users');
          return addDoc(userRef, { email, name, phone, profilePicture });
        }),
        catchError((err) => {
          if (err.code === 'auth/email-already-in-use') {
            this.emailError = '*Email already taken';
            this.showErrors = true;
          }
          return of('taken');
        })
      )
      .subscribe((data) => {
        if (data !== 'taken') this.router.navigate(['/home']);
      });
  }
}
