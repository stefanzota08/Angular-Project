import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  errorMsg: string = '';
  loginForm!: FormGroup;
  firebaseErrorMessage!: string;

  constructor(
    private readonly fb: FormBuilder,
    private readonly authService: AuthService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  login() {
    this.authService
      .loginUser(this.loginForm.value.email, this.loginForm.value.password)
      .pipe(
        catchError((err) => {
          if (err.code === 'auth/user-not-found') {
            this.errorMsg = '*User not found';
          }
          if (err.code === 'auth/invalid-email') {
            this.errorMsg = '*Invalid Email';
          }
          return of('err');
        })
      )
      .subscribe((data) => {
        if (data !== 'err') {
          this.router.navigate(['/home']);
        }
      });
  }
}
