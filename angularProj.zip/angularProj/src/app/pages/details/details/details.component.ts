import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Firestore, collectionData, collection } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
export interface Book {
  id: number;
  title: string;
  author: string;
  description: string;
}

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css'],
})
export class DetailsComponent implements OnInit {
  id: string = '';
  books$!: Observable<any>;
  bookCollection!: Book[];
  currentBook!: any;
  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private readonly firestore: Firestore
  ) {}

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.params.id;
    const books = collection(this.firestore, 'book');
    this.books$ = collectionData(books, { idField: 'id' });
    this.books$
      .pipe(
        switchMap((data) => {
          return data.filter((book: Book) => book.id.toString() === this.id);
        })
      )
      .subscribe((data) => {
        this.currentBook = data;
        console.log(this.currentBook);
      });
  }
}
