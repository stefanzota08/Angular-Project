import { Component, OnInit } from '@angular/core';
import { Firestore, collectionData, collection } from '@angular/fire/firestore';
import { Observable, ObservableInput } from 'rxjs';

export interface Book {
  id: number;
  title: string;
  author: string;
  description: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  books$!: Observable<any>;
  // books: Book[] = [];
  // selectedBooks: Book[] = [];
  constructor(private readonly firestore: Firestore) {}

  ngOnInit(): void {
    const books = collection(this.firestore, 'book');
    this.books$ = collectionData(books, { idField: 'id' });

    // this.books = [
    //   {
    //     id: 1,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 2,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    //   {
    //     id: 3,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 4,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    //   {
    //     id: 1,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 2,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    //   {
    //     id: 3,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 4,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    //   {
    //     id: 1,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 2,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    //   {
    //     id: 3,
    //     title: 'Harry Potter and the Deathly Hallows',
    //     author: 'J.K. Rowling',
    //     description:
    //       "It's no longer safe for Harry at Hogwarts, so he and his best friends, Ron and Hermione, are on the run. Professor Dumbledore has given them clues about what they need to do to defeat the dark wizard, Lord Voldemort, once and for all, but it's up to them to figure out what these hints and suggestions really mean.",
    //   },
    //   {
    //     id: 4,
    //     title: 'The Girl on the Train',
    //     author: 'Paula Hawkins',
    //     description:
    //       "The Girl on the Train is the story of Rachel Watson's life post-divorce. Every day, she takes the train in to work in New York, and every day the train passes by her old house. The house she lived in with her husband, who still lives there, with his new wife and child. As she attempts to not focus on her pain, she starts watching a couple who live a few houses down",
    //   },
    // ];
  }
}
