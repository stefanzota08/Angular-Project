import { Router } from '@angular/router';
import { map, switchMap } from 'rxjs/operators';
import { AuthGuard } from './../../services/auth.guard';
import { AuthService } from 'src/app/services/auth.service';
import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  loggedIn!: Observable<any>;
  checkLoggedIn!: boolean;
  items: MenuItem[] = [];
  activeItem!: MenuItem;

  constructor(
    private readonly authService: AuthService,
    private readonly authGuard: AuthGuard,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.authService.userData$.subscribe((data) => {
      this.items = [
        { label: 'Home', icon: 'pi pi-fw pi-home', routerLink: '/home' },
        {
          label: 'Books',
          icon: 'pi pi-fw pi-info-circle',
          routerLink: '/dashboard',
        },
        { label: 'Profile', icon: 'pi pi-fw pi-user', routerLink: '/profile' },
        {
          label: data?.email ? 'Logout' : 'Login',
          icon: data?.email ? 'pi pi-fw pi-power-off' : 'pi pi-fw pi-sign-in',
          routerLink: '/login',
          command: () => {
            if (data?.email === '') return;

            this.authService.logout();
          },
        },
      ];
      this.activeItem = this.items[0];
    });
  }
}
