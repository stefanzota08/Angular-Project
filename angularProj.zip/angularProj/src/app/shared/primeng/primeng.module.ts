import { NgModule } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { CardModule } from 'primeng/card';
import { TabMenuModule } from 'primeng/tabmenu';
import { ListboxModule } from 'primeng/listbox';
import { DialogModule } from 'primeng/dialog';
import { FileUploadModule } from 'primeng/fileupload';
const importExports = [
  ButtonModule,
  InputTextModule,
  CardModule,
  TabMenuModule,
  ListboxModule,
  DialogModule,
  FileUploadModule,
];

@NgModule({
  imports: importExports,
  exports: importExports,
})
export class PrimeNgModule {}
