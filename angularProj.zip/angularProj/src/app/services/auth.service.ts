import { Injectable } from '@angular/core';
import {
  Auth,
  createUserWithEmailAndPassword,
  deleteUser,
  signInWithEmailAndPassword,
  signOut,
} from '@angular/fire/auth';
import { Firestore } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { onAuthStateChanged } from 'firebase/auth';
import { BehaviorSubject, from, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  userLoggedIn!: boolean;
  userEmail$: BehaviorSubject<any> = new BehaviorSubject(null);

  get userData$(): Observable<any> {
    return this.userEmail$.asObservable();
  }

  constructor(
    private router: Router,
    private readonly auth: Auth,
    private readonly firestore: Firestore
  ) {
    this.userLoggedIn = false;
  }

  loginUser(email: string, password: string): Observable<any> {
    return from(signInWithEmailAndPassword(this.auth, email, password));
  }

  signupUser(user: any): Observable<any> {
    return from(
      createUserWithEmailAndPassword(this.auth, user.email, user.password)
    );
  }

  deleteAccount(user: any): Observable<any> {
    return from(deleteUser(user));
  }

  logout(): Observable<any> {
    return from(signOut(this.auth));
  }

  getUser(): void {
    onAuthStateChanged(this.auth, (user) => {
      if (user) {
        this.userEmail$.next({ email: user.email });
      } else {
        this.userEmail$.next({ email: '' });
      }
    });
  }
}
