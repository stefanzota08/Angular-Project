import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { BookComponent } from './components/book/book.component';
import { PrimeNgModule } from './shared/primeng/primeng.module';
import { RegisterComponent } from './pages/register/register.component';
import { LoginComponent } from './pages/login/login.component';
import { TruncatePipe } from './pipes/truncate.pipe';
import { DashboardViewComponent } from './pages/dashboard/dashboard-view/dashboard-view/dashboard-view.component';
import { DetailsComponent } from './pages/details/details/details.component';
import { ProfileComponent } from './pages/profile/profile/profile.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { HomeComponent } from './pages/home/home.component';
import { provideFirebaseApp, getApp, initializeApp } from '@angular/fire/app';
import { HttpClientModule } from '@angular/common/http';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PdfViewerComponent } from 'ng2-pdf-viewer';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { AuthService } from './services/auth.service';
import { provideAuth } from '@angular/fire/auth';
import { getAuth } from 'firebase/auth';
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    DashboardComponent,
    BookComponent,
    TruncatePipe,
    DashboardViewComponent,
    DetailsComponent,
    ProfileComponent,
    NavbarComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    CommonModule,
    PrimeNgModule,
    HttpClientModule,
    PdfViewerModule,
    provideFirebaseApp(() =>
      initializeApp({
        apiKey: 'AIzaSyDrFILa7YxmAFtofNW2NepDW6r-cY_xQiM',
        authDomain: 'angular-project-6bf1f.firebaseapp.com',
        databaseURL:
          'https://angular-project-6bf1f-default-rtdb.firebaseio.com',
        projectId: 'angular-project-6bf1f',
        storageBucket: 'angular-project-6bf1f.appspot.com',
        messagingSenderId: '603888483058',
        appId: '1:603888483058:web:de8eaaf4866b13d9e3ae6b',
        measurementId: 'G-RCQ6NQ7FH6',
      })
    ),
    provideFirestore(() => getFirestore()),
    provideAuth(() => getAuth()),
  ],
  providers: [AuthService],
  bootstrap: [AppComponent],
})
export class AppModule {}
