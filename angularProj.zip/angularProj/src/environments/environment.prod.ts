export const environment = {
  firebase: {
    projectId: 'angular-project-6bf1f',
    appId: '1:603888483058:web:de8eaaf4866b13d9e3ae6b',
    storageBucket: 'angular-project-6bf1f.appspot.com',
    apiKey: 'AIzaSyDrFILa7YxmAFtofNW2NepDW6r-cY_xQiM',
    authDomain: 'angular-project-6bf1f.firebaseapp.com',
    messagingSenderId: '603888483058',
    measurementId: 'G-RCQ6NQ7FH6',
  },
  production: true
};
