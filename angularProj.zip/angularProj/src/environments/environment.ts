// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    projectId: 'angular-project-6bf1f',
    appId: '1:603888483058:web:de8eaaf4866b13d9e3ae6b',
    storageBucket: 'angular-project-6bf1f.appspot.com',
    apiKey: 'AIzaSyDrFILa7YxmAFtofNW2NepDW6r-cY_xQiM',
    authDomain: 'angular-project-6bf1f.firebaseapp.com',
    messagingSenderId: '603888483058',
    measurementId: 'G-RCQ6NQ7FH6',
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
